import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

def processar_bode():
    caminho_csv = input("Digite o caminho completo do arquivo .csv: ")

    try:
        # 1. Tenta ler o arquivo (UTF-8 primeiro, depois Latin-1)
        try:
            df = pd.read_csv(caminho_csv, sep=';', decimal=',', encoding='utf-8')
        except UnicodeDecodeError:
            df = pd.read_csv(caminho_csv, sep=';', decimal=',', encoding='latin-1')
        
        # Limpeza radical nos nomes das colunas
        df.columns = [str(col).strip() for col in df.columns]
        print(f"Colunas identificadas: {df.columns.tolist()}")

        # 2. Identificação robusta por "palavras-chave" (evita erro de acento)
        col_tempo = 'DataHora'
        col_entrada = [c for c in df.columns if 'Vari' in c][0] # Variável_Controlada
        col_saida = [c for c in df.columns if 'Posi' in c][0]   # Posição
        
        print(f"Usando Entrada: {col_entrada} | Saída: {col_saida}")

        # 3. Tratamento do Tempo e Frequência de Amostragem (fs)
        df[col_tempo] = pd.to_datetime(df[col_tempo], format='%d/%m/%Y - %H:%M:%S,%f')
        # Calcula a diferença média de tempo entre as amostras
        dt = df[col_tempo].diff().mean().total_seconds()
        fs = 1.0 / dt
        print(f"Intervalo médio: {dt:.4f}s (Freq. Amostragem: {fs:.2f} Hz)")

        # 4. Conversão para Arrays Numpy (Isso evita o erro de 'tuple' e 'MultiIndex')
        u = df[col_entrada].values.astype(float)
        y = df[col_saida].values.astype(float)

        # 5. Análise de Frequência (Estimativa de Bode)
        # Ajusta o tamanho do segmento para não ultrapassar o tamanho dos dados
        n_pontos = len(u)
        nperseg_ajustado = min(1024, n_pontos // 2) 

        f, Pxy = signal.csd(u, y, fs=fs, nperseg=nperseg_ajustado)
        f, Pxx = signal.welch(u, fs=fs, nperseg=nperseg_ajustado)
        H = Pxy / Pxx  # Resposta do sistema

        # 6. Plotagem do Gráfico
        plt.figure(figsize=(12, 8))
        
        # Magnitude
        ax1 = plt.subplot(2, 1, 1)
        ax1.semilogx(f, 20 * np.log10(np.abs(H)))
        ax1.set_title('Diagrama de Bode Estimado (Dados Reais)')
        ax1.set_ylabel('Magnitude (dB)')
        ax1.grid(True, which="both", ls="-", alpha=0.5)

        # Fase
        ax2 = plt.subplot(2, 1, 2)
        ax2.semilogx(f, np.angle(H, deg=True))
        ax2.set_ylabel('Fase (graus)')
        ax2.set_xlabel('Frequência (Hz)')
        ax2.grid(True, which="both", ls="-", alpha=0.5)

        plt.tight_layout()
        plt.show()

    except Exception as e:
        print(f"\n[ERRO]: Ocorreu um problema: {e}")
        print("Dica: Verifique se o arquivo CSV está fechado no Excel antes de rodar.")

if __name__ == "__main__":
    processar_bode()