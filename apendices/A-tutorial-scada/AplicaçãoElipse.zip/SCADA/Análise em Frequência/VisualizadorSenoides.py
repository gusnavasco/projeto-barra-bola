import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def fit_sine(t, y, freq):
    """Ajusta uma senóide perfeita aos dados (Mínimos Quadrados)."""
    omega = 2 * np.pi * freq
    # Criamos a matriz de base: sin, cos e offset
    A = np.column_stack([np.sin(omega * t), np.cos(omega * t), np.ones_like(t)])
    # Resolvemos o sistema linear
    params, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    a, b, offset = params
    
    # Calculamos a senóide ajustada
    y_fit = a * np.sin(omega * t) + b * np.cos(omega * t) + offset
    amplitude = np.sqrt(a**2 + b**2)
    fase_rad = np.arctan2(b, a)
    
    return y_fit, amplitude, fase_rad

def iniciar_do_zero():
    # 1. Input do arquivo
    arquivo = input("Digite o nome do arquivo CSV: ")
    
    try:
        # Carregamento com as configurações que funcionam no seu Excel/CSV
        df = pd.read_csv(arquivo, sep=';', decimal=',', encoding='latin-1')
        df.columns = [c.strip() for c in df.columns]
        
        # 2. Solicitação do Período e Validação
        entrada_periodo = input("Digite o valor do período desejado (ex: 6.0 ou 7.8): ")
        
        try:
            # Convertemos a entrada para float para comparar com a coluna numérica
            periodo_selecionado = float(entrada_periodo.replace(',', '.'))
        except ValueError:
            print("Por favor, digite um número válido para o período.")
            return

        # Verifica se o valor existe na coluna 'Período'
        if periodo_selecionado not in df['Período'].values:
            print(f"\nO valor desejado '{entrada_periodo}' não se encontra na coluna 'Período' do arquivo .csv indicado.")
            return

        # 3. Tratamento de Tempo
        df['DataHora_dt'] = pd.to_datetime(df['DataHora'], format='%d/%m/%Y - %H:%M:%S,%f')
        df['Time_Sec'] = (df['DataHora_dt'] - df['DataHora_dt'].iloc[0]).dt.total_seconds()
        
        # 4. Filtrar pelo Período escolhido
        grupo_dados = df[df['Período'] == periodo_selecionado].copy()
        
        # Descarte de transiente (pegamos os últimos 60% do bloco para estabilidade)
        corte = int(len(grupo_dados) * 0.9)
        estavel = grupo_dados.iloc[corte:]
        
        t = estavel['Time_Sec'].values
        y_sp = estavel['Setpoint'].values
        y_pos = estavel['Posição'].values
        
        # Frequência calculada com base na escolha do usuário
        freq_escolhida = 1.0 / periodo_selecionado
        
        # 5. Ajuste das Senóides (A mágica matemática)
        fit_sp, amp_sp, fase_sp = fit_sine(t, y_sp, freq_escolhida)
        fit_pos, amp_pos, fase_pos = fit_sine(t, y_pos, freq_escolhida)
        
        # 6. Visualização
        plt.figure(figsize=(12, 7))
        
        # Subplot Setpoint
        plt.subplot(2, 1, 1)
        plt.plot(t, y_sp, 'lightgray', label='Setpoint Real (Dados)')
        plt.plot(t, fit_sp, 'blue', lw=2, label='Seno Ajustado (Setpoint)')
        plt.title(f'Validação de Ajuste Senoidal - Período Selecionado = {periodo_selecionado}s')
        plt.ylabel('Amplitude')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Subplot Posição
        plt.subplot(2, 1, 2)
        plt.plot(t, y_pos, 'orange', alpha=0.5, label='Posição Real (Dados)')
        plt.plot(t, fit_pos, 'red', lw=2, label='Seno Ajustado (Posição)')
        plt.ylabel('Amplitude')
        plt.xlabel('Tempo (s)')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        # 7. Resultados no console
        # Evita divisão por zero se a amplitude for ínfima
        if amp_sp > 0:
            ganho_db = 20 * np.log10(amp_pos/amp_sp)
            atraso_fase = np.degrees(fase_pos - fase_sp)
            
            # Ajuste de fase para garantir que o atraso faça sentido (opcional)
            if atraso_fase > 180: atraso_fase -= 360
            if atraso_fase < -180: atraso_fase += 360

            print(f"\n--- Resultados para T={periodo_selecionado}s ---")
            print(f"Amostras analisadas: {len(estavel)}")
            print(f"Ganho: {ganho_db:.4f} dB")
            print(f"Fase: {atraso_fase:.4f} graus")
        else:
            print("\nErro: Amplitude do Setpoint é zero, impossível calcular Ganho.")

    except Exception as e:
        print(f"Erro: {e}")

if __name__ == "__main__":
    iniciar_do_zero()