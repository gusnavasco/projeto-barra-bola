import pandas as pd
import matplotlib.pyplot as plt

def analisar_senoides():
    # 1. Solicita o nome do arquivo
    arquivo_csv = input("Digite o nome do arquivo CSV (ex: InfoTeste.csv): ")

    try:
        # 2. Leitura com encoding correto e detecção automática de separador
        df = pd.read_csv(arquivo_csv, encoding='latin-1', sep=None, engine='python')
        
        # 3. Solicita o período ao usuário
        periodo_desejado = input("Digite o valor do período desejado (ex: 7,8): ")

        # 4. Verifica se o valor existe na coluna 'Período'
        if periodo_desejado not in df['Período'].astype(str).values:
            print(f"\nO valor desejado '{periodo_desejado}' não se encontra na coluna 'Período' do arquivo .csv indicado.")
            return

        # 5. Filtra os dados
        dados_filtrados = df[df['Período'].astype(str) == periodo_desejado]

        # 6. Exibe o resumo que você gostou
        print("-" * 30)
        print(f"Dados carregados com sucesso para o período {periodo_desejado}!")
        print(f"Número de amostras encontradas: {len(dados_filtrados)}")
        print("-" * 30)

        # --- GERAÇÃO DO GRÁFICO DA SENOIDE ---
        # Nota: Ajustei para nomes comuns como 'Tempo' e 'Tensao'. 
        # Se os nomes forem diferentes no seu CSV, basta alterar abaixo.
        
        plt.figure(figsize=(12, 6))
        
        # Identificando as colunas automaticamente para o gráfico (X e Y)
        # Se você souber os nomes exatos, pode substituir 'df.columns[1]' pelo nome real
        coluna_x = 'Tempo'  # ou df.columns[idx]
        coluna_y = 'Valor'  # ou o nome da coluna do sinal senoidal

        plt.plot(dados_filtrados[coluna_x], dados_filtrados[coluna_y], marker='o', linestyle='-', color='b')
        
        plt.title(f'Visualização da Senoide - Período: {periodo_desejado}')
        plt.xlabel('Tempo (s)')
        plt.ylabel('Amplitude / Tensão')
        plt.grid(True)
        
        plt.show()

    except FileNotFoundError:
        print(f"Erro: O arquivo '{arquivo_csv}' não foi encontrado.")
    except KeyError as e:
        print(f"Erro: A coluna {e} não foi encontrada. Verifique se os nomes no CSV estão corretos.")
        print(f"Colunas detectadas no seu arquivo: {list(df.columns)}")
    except Exception as e:
        print(f"Ocorreu um erro inesperado: {e}")

if __name__ == "__main__":
    analisar_senoides()